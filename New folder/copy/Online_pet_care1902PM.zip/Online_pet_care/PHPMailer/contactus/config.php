<?php

$myemail = "e1841116@bit.mrt.ac.lk";
$mypassword = "Kushan1995*";

?>
