<?php
session_start();
require('db_conn.php');


$email = $_SESSION['email'];
$Approvalstatus= 'pending';


$selectSQL = "SELECT * FROM appointment INNER JOIN doctorschedule ON doctorschedule.scheduleId = appointment.scheduleID WHERE doctorschedule.Doc_email='$email' AND appointment.Status='$Approvalstatus'";
    $r1= mysqli_query($conn, $selectSQL);
    if(mysqli_error($conn)){
        echo "Errror: ".mysqli_error($conn);
    }
    $status2 = "Accepted";
    $status3 = "Rejected";
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">

   
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href=".\image\icon3.jpg">

    <title>Pending Appointment</title>

    <link rel="canonical" href=".\bootstrap-4.0.0\docs\4.0\examples\jumbotron">

    <!-- Bootstrap core CSS -->
    <link href=".\bootstrap-4.0.0\dist\css\bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href=".\bootstrap-4.0.0\docs\4.0\examples\jumbotron" rel="stylesheet">
  </head>

  <body>

    <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
      <a class="navbar-brand" href="#"></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarsExampleDefault">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
            <a class="nav-link" href="dashboardDoctor.php">Home <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="profiledetails.php">My Details</a>
          </li>

          <li class="nav-item">
            <a class="nav-link inactive" href="Pending_appointment.php">Pending Appointment</a>
          </li>

          <li class="nav-item">
            <a class="nav-link active" href="doctorschedule.php">Doctor Schedule</a>
          </li>


          </ul>

        <form class="form-inline my-2 my-lg-0">
          <input class="form-control mr-sm-2" type="text" placeholder="Search" aria-label="Search">
          <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>

          <ul class="navbar-nav mr-auto">

          <li class="nav-item">
            <a class="nav-link active" href="logout.php">Logout</a>
          </li></ul>
        </form>
      </div>
    </nav>
<br>
<br>
    <main role="main">     
    
        <hr>

      </div> <!-- /container -->

                                <!-- Table -->
                        <table class="table table-hover table-bordered">
                            <thead>
                                <tr class="filters">
                                    
                                    <th><input type="text" class="form-control" placeholder="scheduleDate" disabled></th>
                                    <th><input type="text" class="form-control" placeholder="Pet Name" disabled></th>
                                    <th><input type="text" class="form-control" placeholder="Symptom" disabled></th>
                                    <th><input type="text" class="form-control" placeholder="Comment" disabled></th>
                                    <th><input type="text" class="form-control" placeholder="Task" disabled></th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php  
                              while ($row = mysqli_fetch_assoc($r1)) {
                              ?>
                                 <tr>
                                      <td><?php echo $row['scheduleDate']?></td>
                                      <td><?php echo $row['Petname']?></td>
                                      <td><?php echo $row['app_symptm']?></td>
                                      <td><?php echo $row['comment']?></td> 

                                      
                                      
                                      <td><a href="Pending_appointment.php?Service_approve=<?php echo $Service_approve=$row['scheduleId']?>" Action = "$status2" class="btn btn-primary">Accept</a>
                                        <a href="Pending_appointment.php?Service_reject=<?php echo $Service_reject=$row['scheduleId']?>" Action = "$status3" class="btn btn-primary">Reject</a>

                                      </td>

                                      
                                  </tr>
                              <?php
                              }
                              ?>
  </tbody>
   </table>   

    </main>

    <?php
    $status = '';
    if (isset($_GET['Service_approve'])) {
         $Approval_id = $_GET['Service_approve'];


         $query4="SELECT pet_owners.email FROM appointment inner join pet_owners on appointment.ID = pet_owners.Id WHERE appointment.scheduleID='$Approval_id'";
         $r4= mysqli_query($conn, $query4);
       
         $nor4= mysqli_num_rows($r4);
           //print_r($nor1);
           if($nor4>0){
                   while ($row4= mysqli_fetch_array($r4)){
                       //print_r($row1);
                       $pet_ownersEmail=$row4['email'];
       
                   }
                 }

         //echo "$Approval_id";
         $status2="Accepted";

         $query2="UPDATE appointment SET Status='$status2' WHERE scheduleId ='$Approval_id'";


        $r2= mysqli_query($conn, $query2);
        
          $page;

         
          $to = 'kushan_r@gssintl.biz';
          $mail_subject = 'final project';
          $email_body = 'We would like to inform you Your appointment  has been accapted by Doctor';
          $header = "From: e1841116@bit.mrt.ac.lk" . "\r\nContent-Type: text/html;";
          
          
          $send_mail_result = mail($to,$mail_subject,$email_body,$header);
          if ( $send_mail_result ) {
            $status = '<p class="success">Message Sent Successfully.</p>';
          } else {
            $status = '<p class="error">Error: Message Was Not Sent.</p>';
          }
        
       
    }elseif (isset($_GET['Service_reject'])) {
          $Approval_id = $_GET['Service_reject'];

         $status3="Rejected";
         $query3="UPDATE appointment SET Status='$status3' WHERE scheduleId ='$Approval_id'";


        $r3= mysqli_query($conn, $query3);
        
          $page;
   
    }    else{
      echo "";
    }
    //header('location: doctorschedule.php');
    ?>

<?php echo $status; ?>


    </body>

    <footer class="container">
      <p>&copy; Kushan 2022</p>
    </footer>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src=".\bootstrap-4.0.0\assets\js\vendor\popper.min.js><\/script>')</script>
    <script src=".\bootstrap-4.0.0\assets\js\vendor\popper.min.js"></script>
    <script src=".\bootstrap-4.0.0\dist\js\bootstrap.min.js"></script>
  
</html>
